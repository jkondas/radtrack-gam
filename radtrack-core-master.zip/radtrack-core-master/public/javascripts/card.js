var Card = function() {
	
	var findBy = function(id) {
		alert("find card "  + id)
	}
	
}

